function plotfile(filename)

[A,X,Y] = readfile(filename);

contour(X,Y,A,10),axis('square'),grid,
xlabel('Y'),ylabel('X')
