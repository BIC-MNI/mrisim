function [A,X,Y] = readfile(filename)

fid = fopen(filename,'r');

% Read matrix size
skipchar(fid,10);
N = fscanf(fid,'%d',1);
skipchar(fid,5);
Ymin = fscanf(fid,'%lf',1);
skipchar(fid,3);
Ymax = fscanf(fid,'%lf',1);
Y = linspace(Ymin,Ymax,N);
skipline(fid);

skipchar(fid,9);
M = fscanf(fid,'%d',1);
skipchar(fid,5);
Xmin = fscanf(fid,'%lf',1);
skipchar(fid,3);
Xmax = fscanf(fid,'%lf',1);
X = linspace(Xmin,Xmax,M);
skipline(fid);

%c = fread(fid,1,'char');
%while (c ~= '\n'),
%   c = fread(fid,1,'char');
%end

A = zeros(M,N);
COUNT = 0;
for x = 1:M,
   [tmp,count] = fscanf(fid,'%lf,',N);
   A(x,:)      = tmp';
   COUNT       = COUNT + count;
end

fclose(fid);
