function skipchar(fid,n)

   c = fread(fid,n,'char');
