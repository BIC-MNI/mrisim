function skipline(fid)

c = fread(fid,1,'char');
while (c ~= 10),
   c = fread(fid,1,'char');
end
