% Data file name
file = 'qhc';

% Load data points and scale to -4095..4095
[A,X,Y] = readfile([file,'.dat']);
Amin = min(min(A));
Amax = max(max(A));
A = (A-Amin)./(Amax-Amin).*2*4095-4095;

% Save three identical slices as a raw file
fid = fopen([file,'.raw'],'wb'); 
fwrite(fid,A,'short'); 
fwrite(fid,A,'short'); 
fwrite(fid,A,'short'); 
fclose(fid);

% Compute start and step sizes for the minc volume
Xstart = min(X)*1000;
Ystart = min(Y)*1000;
Xfov   = (max(X)-min(X))*1000;
Yfov   = (max(Y)-min(Y))*1000;
Xstep  = Xfov./(length(X)-1);
Ystep  = Yfov./(length(Y)-1);

% Generate minc file from raw data
rawtominc = ['!rawtominc -short -oshort -input ', file,'.raw ', ...
        '-range -4095 4095 -real_range ',num2str(Amin), ' ',num2str(Amax),...
        ' -xstep ',num2str(Xstep), ' -ystep ',num2str(Ystep),...
        ' -zstep 100 -zstart -100',...
        ' -xstart ',num2str(Xstart),' -ystart ',num2str(Ystart),...
        ' -xdircos 1 0 0 -ydircos 0 1 0 -zdircos 0 0 1 -clobber tmp.mnc 3 ',...
        num2str(length(X)),' ',num2str(length(Y))];
eval(rawtominc)

% Resample minc volume
mincresample = ['!mincresample -tricubic -xstep 1 -ystep 1 -nelements ',...
        num2str(Xfov),' ',num2str(Yfov),' 3 -clobber tmp.mnc ',...
        file,'.mnc'];
eval(mincresample)

% Delete temporary files
del = ['delete ',file,'.raw'];
eval(del)
delete tmp.mnc;
